#！/usr/bin/env python
#-*- coding:utf-8 -*-
#Author:xiaochao

import sys

print(sys.argv)
#获取python版本信息
print(sys.version)
#返回操作系统平台名称
print(sys.platform)
#获取最大int值
print(sys.maxsize)